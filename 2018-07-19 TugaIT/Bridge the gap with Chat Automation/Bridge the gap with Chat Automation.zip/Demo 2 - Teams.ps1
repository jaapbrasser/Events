# Show setting up the webhook connector

# First message
$WebHookSplat = @{
    Method = 'post'
    ContentType = 'Application/Json'
    Body = '{"text":"Hello Tuga IT!"}'
    Uri = 'https://outlook.office.com/webhook/xxxxxxxxxxxxxxxxxxxxxxxxxxxx'
}
Invoke-WebRequest @WebHookSplat

$WebHookSplat.Body = @'
{
    "@type": "MessageCard",
    "@context": "http://schema.org/extensions",
    "summary": "Using Chat Automation",
    "title": "TugaIT",
    "sections": [
        {
            "activityTitle": "Jaap is presenting",
            "activitySubtitle": "On Chat Automation",
            "activityText": "\"Incoming webhook\"",
            "activityImage": "https://upload.wikimedia.org/wikipedia/commons/2/2f/PowerShell_5.0_icon.png"
        }
    ]
}
'@
Invoke-WebRequest @WebHookSplat

$WebHookSplat.Body = @'
{
    "@type": "MessageCard",
    "@context": "http://schema.org/extensions",
    "summary": "Using Chat Automation",
    "title": "TugaIT",
    "sections": [
        {
            "activityTitle": "Jaap is presenting",
            "activitySubtitle": "On Chat Automation",
            "activityText": "\"Incoming webhook\"",
            "activityImage": "https://upload.wikimedia.org/wikipedia/commons/2/2f/PowerShell_5.0_icon.png"
        }
    ]
}
'@
Invoke-WebRequest @WebHookSplat




$SysErrors = (Get-WinEvent -FilterHashtable @{
    Logname="System"
    Level=2
    StartTime=(Get-Date).AddMonths(-1)
} | Measure-Object).Count
$SysWarnings = (Get-WinEvent -FilterHashtable @{
    Logname="System"
    Level=3
    StartTime=(Get-Date).AddMonths(-1)
} | Measure-Object).Count
$WebHookSplat.Body = @"
{
    "@type": "MessageCard",
    "@context": "http://schema.org/extensions",
    "summary": "Using Chat Automation",
    "title": "TugaIT",
    "sections": [
        {
            "activityTitle": "System Log Errors",
            "activitySubtitle": "Number of errors:",
            "activityText": "$($SysErrors)",
            "activityImage": "https://upload.wikimedia.org/wikipedia/commons/2/2f/PowerShell_5.0_icon.png"
        },
        {
            "activityTitle": "System Log Warnings",
            "activitySubtitle": "Number of warnings:",
            "activityText": "$($SysWarnings)",
            "activityImage": "https://upload.wikimedia.org/wikipedia/commons/2/2f/PowerShell_5.0_icon.png"
        }
    ]
}
"@
Invoke-WebRequest @WebHookSplat

# Microsoft <3 Linux

curl -H "Content-Type: application/json" -d "{\"text\": \"Hello Tuga IT! Microsoft <3 Linux\"}" https://outlook.office.com/webhook/xxxxxxxxxxxxxxxxxxxxxxxxxxxx
