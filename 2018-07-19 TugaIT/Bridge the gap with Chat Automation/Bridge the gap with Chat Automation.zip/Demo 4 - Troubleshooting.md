# Is the server online?
!ping localhost

# Return disk information
!get-diskspace

# Return event log errors
!get-systemerrorevents
!get-systemerrorevents 5

# Get-Service
!get-webservice

# Restart iis
!restart-webservice

# [Math] .Net code execution / Error handling
!invoke-codeexecution "[math]::power(2,10)"
!invoke-codeexecution "[math]::pow(2,10)"

# Command prompt?
!invoke-codeexecution "cmd /c dir c:\"

# What?
!invoke-codeexecution "shutdown /h /f"