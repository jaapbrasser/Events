$FlowModulePath = 'Flow.psm1'
Import-Module $FlowModulePath

Get-Command -Module PowerShellFlow

# Check Data Gateway service
Get-Service PBIEgwService

# Switch to Admin PowerShell console
$FlowModulePath = 'Flow.psm1'
Import-Module $FlowModulePath
Start-FlowAgent

# Switch to Phone
