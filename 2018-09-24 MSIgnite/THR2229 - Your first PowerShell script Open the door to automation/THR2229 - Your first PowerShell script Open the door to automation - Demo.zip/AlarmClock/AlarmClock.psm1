function Start-AlarmClock {
<#
.SYNOPSIS
After a set number of seconds this function will beep until switched off with <CTRL> + C
#>
    param(
        [int] $Seconds
    )
    
    "Alarm will trigger after $Seconds seconds, press <CTRL> C to stop the alarm"

    Start-Sleep -Seconds $Seconds
    while ($true) {
        [console]::Beep()
    }
}