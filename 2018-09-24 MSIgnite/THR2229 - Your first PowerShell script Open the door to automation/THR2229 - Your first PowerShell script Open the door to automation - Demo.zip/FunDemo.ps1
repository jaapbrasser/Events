# Shall we play a game?
Start-Process powershell -ArgumentList '-noprofile -noexit -command .\PSInvaders.ps1'
Start-Process pwsh -ArgumentList '-noprofile -noexit -command .\PSInvaders.ps1'

<# 
Project is available on GitHub:
https://github.com/soapyfrog/miscps1/tree/master/psinvaders
#> 

# Display overview of workflow
Invoke-Item .\HeyPowerShellDemo.png

# Configure rest call hash table
$HashSplat = @{
    Uri = 'https://westus.stt.speech.microsoft.com/speech/recognition/conversation/cognitiveservices/v1?language=en-US'
    Headers = @{
    'Ocp-Apim-Subscription-Key' = '7979bdf0efbf456eb0e3c496123deca4';
    'Transfer-Encoding' = 'chunked';
    'Content-type' = 'audio/wav; codec=audio/pcm; samplerate=44000';
    'Host' = 'westus.stt.speech.microsoft.com'
    }
    Body = [System.IO.File]::ReadAllBytes('C:\Users\Jaap Brasser\OneDrive\SyncToPhone\HeyPowerShellPlaySomeMusic.wav')
    Method = 'Post'
}
Clear

# Assign output to variable and show output
$(Invoke-RestMethod @HashSplat) | Tee-Object -Variable SpeechOutput
$SpeechOutput.DisplayText

#region If demo fails, use prepared xml
Import-Clixml .\ExpectedSpeechOutput.xml
$SpeechOutput = Import-Clixml .\ExpectedSpeechOutput.xml
#endregion

# Execute script if power and music are both present in the speech output
if ($SpeechOutput.DisplayText -like '*power*shell*music*') {
    iex (iwr http://bit.ly/e0Mw9w)
} else {
    "I am afraid I can't do that Jaap"
}

# Switch back to slides